class Model_List:
    def __init__(self): 
        self.items=[]
        self.done=[]

class View:
    def __init__(self,controller=None):
        self.controller = controller

class Controller:
    def __init__(self, model):
        self.model = model    

